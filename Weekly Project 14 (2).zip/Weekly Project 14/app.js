$(document).ready(function(){
    $("#kt1").mouseEnter(function(){
        $("#kt").toggleClass(".hide")
    })
});

